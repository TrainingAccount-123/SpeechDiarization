/* =========================================
   MeetScribe - Main Application Logic
   ========================================= */

(function () {
  "use strict";

  // ---- State ----
  let captionsData = []; // raw captions from API
  let speakerMap = {}; // e.g. { "A": "John Doe", "B": "Jane" }
  let audioSegments = {}; // e.g. { "A": "/path/to/a.mp3", ... }
  let audioElements = {}; // Audio() instances per speaker
  let hasData = false;

  // ---- DOM refs ----
  const uploadSection = document.getElementById("uploadSection");
  const uploadArea = document.getElementById("uploadArea");
  const fileInput = document.getElementById("fileInput");
  const browseBtn = document.getElementById("browseBtn");
  const uploadProgress = document.getElementById("uploadProgress");
  const uploadStatusText = document.getElementById("uploadStatusText");
  const progressBarFill = document.getElementById("progressBarFill");
  const resultsSection = document.getElementById("resultsSection");
  const speakerList = document.getElementById("speakerList");
  const captionsList = document.getElementById("captionsList");
  const captionCount = document.getElementById("captionCount");
  const downloadPdfBtn = document.getElementById("downloadPdfBtn");
  const newUploadBtn = document.getElementById("newUploadBtn");
  const confirmModal = document.getElementById("confirmModal");
  const cancelUploadBtn = document.getElementById("cancelUploadBtn");
  const confirmUploadBtn = document.getElementById("confirmUploadBtn");

  // ---- Persistence (sessionStorage) ----
  const STORAGE_KEY_MAP = "meetscribe_speaker_map";
  const STORAGE_KEY_CAPTIONS = "meetscribe_captions";
  const STORAGE_KEY_SEGMENTS = "meetscribe_segments";

  function savePersistence() {
    sessionStorage.setItem(STORAGE_KEY_MAP, JSON.stringify(speakerMap));
    sessionStorage.setItem(STORAGE_KEY_CAPTIONS, JSON.stringify(captionsData));
    sessionStorage.setItem(STORAGE_KEY_SEGMENTS, JSON.stringify(audioSegments));
  }

  function loadPersistence() {
    try {
      const map = sessionStorage.getItem(STORAGE_KEY_MAP);
      const captions = sessionStorage.getItem(STORAGE_KEY_CAPTIONS);
      const segments = sessionStorage.getItem(STORAGE_KEY_SEGMENTS);
      if (map) speakerMap = JSON.parse(map);
      if (captions) captionsData = JSON.parse(captions);
      if (segments) audioSegments = JSON.parse(segments);
      return captionsData.length > 0;
    } catch {
      return false;
    }
  }

  function clearPersistence() {
    sessionStorage.removeItem(STORAGE_KEY_MAP);
    sessionStorage.removeItem(STORAGE_KEY_CAPTIONS);
    sessionStorage.removeItem(STORAGE_KEY_SEGMENTS);
    speakerMap = {};
    captionsData = [];
    audioSegments = {};
    audioElements = {};
    hasData = false;
  }

  // ---- Helpers ----
  function formatTime(seconds) {
    const s = Math.floor(seconds);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    const h = Math.floor(m / 60);
    const min = m % 60;
    if (h > 0) {
      return `${h}:${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    }
    return `${min}:${String(sec).padStart(2, "0")}`;
  }

  function getSpeakerColor(speaker) {
    const colors = ["a", "b", "c", "d", "e", "f"];
    const idx = speaker.charCodeAt(0) - 65; // A=0, B=1, ...
    return colors[idx % colors.length];
  } 

  function getDisplayName(speaker) {
    return speakerMap[speaker] && speakerMap[speaker].trim()
      ? speakerMap[speaker].trim()
      : `Speaker ${speaker}`;
  }

  function getUniqueSpeakers() {
    const seen = new Set();
    captionsData.forEach((c) => seen.add(c.speaker));
    return Array.from(seen).sort();
  }

  // ---- Rendering ----
  function renderCaptions() {
    captionsList.innerHTML = "";
    captionsData.forEach((item) => {
      const color = getSpeakerColor(item.speaker);
      const div = document.createElement("div");
      div.className = `caption-item caption-item-${color}`;
      div.innerHTML = `
        <div class="caption-timestamp">${formatTime(item.timestamp.start)} - ${formatTime(item.timestamp.end)}</div>
        <div class="caption-speaker caption-speaker-${color}">${getDisplayName(item.speaker)}</div>
        <div class="caption-text">${escapeHtml(item.text)}</div>
      `;
      captionsList.appendChild(div);
    });
    captionCount.textContent = `${captionsData.length} segment${captionsData.length !== 1 ? "s" : ""}`;
  }

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str;
    return d.innerHTML;
  }

  function renderSpeakerCards() {
    speakerList.innerHTML = "";
    const speakers = getUniqueSpeakers();

    speakers.forEach((spk) => {
      const color = getSpeakerColor(spk);
      const card = document.createElement("div");
      card.className = "speaker-card";

      const hasAudio = audioSegments[spk];

      card.innerHTML = `
        <div class="speaker-card-header">
          <div class="speaker-badge speaker-badge-${color}">${spk}</div>
          <span class="speaker-label">Speaker ${spk}</span>
        </div>
        <input
          type="text"
          class="speaker-name-input"
          placeholder="Enter name (e.g. John Doe)"
          value="${speakerMap[spk] ? escapeHtml(speakerMap[spk]) : ""}"
          data-speaker="${spk}"
        />
        ${
          hasAudio
            ? `
        <div class="speaker-audio-player" data-speaker="${spk}">
          <button class="play-btn" data-speaker="${spk}" aria-label="Play audio for Speaker ${spk}">
            <svg viewBox="0 0 24 24" fill="currentColor" stroke="none">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
          </button>
          <div class="audio-bar-track" data-speaker="${spk}">
            <div class="audio-bar-fill" id="audioFill-${spk}"></div>
          </div>
          <span class="audio-time" id="audioTime-${spk}">0:00</span>
        </div>`
            : `<div style="font-size:12px;color:var(--text-secondary);opacity:0.6;">No audio segment available</div>`
        }
      `;

      speakerList.appendChild(card);
    });

    // Bind input events
    speakerList.querySelectorAll(".speaker-name-input").forEach((input) => {
      input.addEventListener("input", handleNameChange);
    });

    // Bind play buttons
    speakerList.querySelectorAll(".play-btn").forEach((btn) => {
      btn.addEventListener("click", handlePlayAudio);
    });

    // Bind audio bar clicks
    speakerList.querySelectorAll(".audio-bar-track").forEach((bar) => {
      bar.addEventListener("click", handleAudioSeek);
    });
  }

  // ---- Event Handlers ----
  function handleNameChange(e) {
    const speaker = e.target.dataset.speaker;
    speakerMap[speaker] = e.target.value;
    savePersistence();
    renderCaptions();
  }

  function handlePlayAudio(e) {
    const btn = e.currentTarget;
    const speaker = btn.dataset.speaker;
    const src = audioSegments[speaker];
    if (!src) return;

    // Pause all others
    Object.keys(audioElements).forEach((k) => {
      if (k !== speaker && audioElements[k]) {
        audioElements[k].pause();
        updatePlayIcon(k, false);
      }
    });

    if (!audioElements[speaker]) {
      audioElements[speaker] = new Audio(src);
      audioElements[speaker].crossOrigin = "anonymous";
      bindAudioEvents(speaker);
    }

    const audio = audioElements[speaker];
    if (audio.paused) {
      audio.play();
      updatePlayIcon(speaker, true);
    } else {
      audio.pause();
      updatePlayIcon(speaker, false);
    }
  }

  function handleAudioSeek(e) {
    const speaker = e.currentTarget.dataset.speaker;
    if (!audioElements[speaker]) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    audioElements[speaker].currentTime = pct * audioElements[speaker].duration;
  }

  function bindAudioEvents(speaker) {
    const audio = audioElements[speaker];
    const fill = document.getElementById(`audioFill-${speaker}`);
    const time = document.getElementById(`audioTime-${speaker}`);

    audio.addEventListener("timeupdate", () => {
      if (fill && audio.duration) {
        fill.style.width = (audio.currentTime / audio.duration) * 100 + "%";
      }
      if (time) {
        time.textContent = formatTime(audio.currentTime);
      }
    });

    audio.addEventListener("ended", () => {
      updatePlayIcon(speaker, false);
      if (fill) fill.style.width = "0%";
      if (time) time.textContent = "0:00";
    });
  }

  function updatePlayIcon(speaker, isPlaying) {
    const btn = speakerList.querySelector(`.play-btn[data-speaker="${speaker}"]`);
    if (!btn) return;
    if (isPlaying) {
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`;
    } else {
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="5,3 19,12 5,21"/></svg>`;
    }
  }

  // ---- Upload Flow ----
  function showUpload() {
    uploadSection.style.display = "";
    resultsSection.style.display = "none";
    downloadPdfBtn.disabled = true;
    uploadArea.style.display = "";
    uploadProgress.style.display = "none";
  }

  function showResults() {
    uploadSection.style.display = "none";
    resultsSection.style.display = "";
    downloadPdfBtn.disabled = false;
    renderSpeakerCards();
    renderCaptions();
  }

  function triggerNewUpload() {
    if (hasData) {
      confirmModal.classList.add("active");
    } else {
      fileInput.click();
    }
  }

  // Drag and drop
  uploadArea.addEventListener("click", (e) => {
    if (e.target === browseBtn || browseBtn.contains(e.target)) return;
    fileInput.click();
  });

  browseBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    fileInput.click();
  });

  uploadArea.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadArea.classList.add("drag-over");
  });

  uploadArea.addEventListener("dragleave", () => {
    uploadArea.classList.remove("drag-over");
  });

  uploadArea.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadArea.classList.remove("drag-over");
    if (e.dataTransfer.files.length > 0) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
      handleFileSelected(fileInput.files[0]);
    }
  });

  function handleFileSelected(file) {
    if (hasData) {
      // Store the file temporarily and show confirmation
      window._pendingFile = file;
      confirmModal.classList.add("active");
      return;
    }
    processFile(file);
  }

  async function processFile(file) {
    // Show progress
    uploadArea.style.display = "none";
    uploadProgress.style.display = "";
    uploadStatusText.textContent = `Uploading "${file.name}"...`;
    progressBarFill.style.width = "20%";

    try {
      // Upload to the transcription API
      const formData = new FormData();
      formData.append("file", file);

      uploadStatusText.textContent = "Transcribing your recording...";
      progressBarFill.style.width = "50%";

      // Fetch captions from AssemblyAI endpoint
      const captionsRes = await fetch("http://127.0.0.1:8000/deepgram/get_captions", {
        method: "POST",
        body: formData,
      });

      if (!captionsRes.ok) throw new Error("Failed to fetch captions");

      progressBarFill.style.width = "75%";
      uploadStatusText.textContent = "Loading audio segments...";

      function toConvertedPath(fileName) {
        const lastDot = fileName.lastIndexOf(".");
        const stem =
          lastDot === -1 ? fileName : fileName.slice(0, lastDot);

        return `./files/${stem}_16k.flac`;
      }

      const audioFilePath = toConvertedPath(file.name)

      const captionsJson = await captionsRes.json();
      console.log(captionsJson)
      captionsData = captionsJson.diarization;


      // Fetch audio segments
      const segmentsRes = await fetch("http://127.0.0.1:8000/deepgram/get_audio_segments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          "audio_file": audioFilePath,
          "diarization": captionsJson.diarization
        }),
      });

      if (segmentsRes.ok) {
        const segmentsJson = await segmentsRes.json();
        audioSegments = segmentsJson;
      }

      progressBarFill.style.width = "100%";
      uploadStatusText.textContent = "Done!";

      hasData = true;
      speakerMap = {};
      savePersistence();

      setTimeout(() => {
        showResults();
      }, 500);
    } catch (err) {
      console.error("Failed to Process the File", err);
      uploadStatusText.textContent = "Error: " + err.message;
      progressBarFill.style.width = "0%";
      setTimeout(() => {
        showUpload();
      }, 25000);
    }
  }

  // ---- Confirm Modal ----
  cancelUploadBtn.addEventListener("click", () => {
    confirmModal.classList.remove("active");
    window._pendingFile = null;
    // Reset file input
    fileInput.value = "";
  });

  confirmUploadBtn.addEventListener("click", () => {
    confirmModal.classList.remove("active");
    clearPersistence();
    hasData = false;
    showUpload();

    // If there was a pending file (from drop or input), process it
    if (window._pendingFile) {
      const f = window._pendingFile;
      window._pendingFile = null;
      processFile(f);
    } else {
      fileInput.click();
    }
  });

  // ---- New Upload ----
  newUploadBtn.addEventListener("click", triggerNewUpload);

  // ---- PDF Download ----
  downloadPdfBtn.addEventListener("click", generatePdf);

  function generatePdf() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const margin = 20;
    const pageWidth = doc.internal.pageSize.getWidth();
    const usableWidth = pageWidth - margin * 2;
    let y = margin;

    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.text("Meeting Captions", margin, y);
    y += 8;

    // Date
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(120, 120, 120);
    doc.text("Generated on " + new Date().toLocaleString(), margin, y);
    y += 4;

    // Separator
    doc.setDrawColor(200, 200, 200);
    doc.line(margin, y, pageWidth - margin, y);
    y += 8;

    // Speaker legend
    const speakers = getUniqueSpeakers();
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 30, 46);
    doc.text("Speakers:", margin, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    speakers.forEach((spk) => {
      doc.setTextColor(80, 80, 80);
      doc.text(`${spk} = ${getDisplayName(spk)}`, margin + 4, y);
      y += 5;
    });
    y += 6;

    doc.line(margin, y, pageWidth - margin, y);
    y += 8;

    // Captions
    captionsData.forEach((item) => {
      const timeStr = `${formatTime(item.timestamp.start)} - ${formatTime(item.timestamp.end)}`;
      const speakerStr = getDisplayName(item.speaker);
      const text = item.text;

      // Check space
      const textLines = doc.splitTextToSize(text, usableWidth - 4);
      const blockHeight = 6 + 5 + textLines.length * 4.5 + 8;

      if (y + blockHeight > doc.internal.pageSize.getHeight() - margin) {
        doc.addPage();
        y = margin;
      }

      // Timestamp
      doc.setFont("courier", "normal");
      doc.setFontSize(9);
      doc.setTextColor(120, 120, 120);
      doc.text(timeStr, margin, y);
      y += 5;

      // Speaker
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(15, 123, 108);
      doc.text(speakerStr, margin, y);
      y += 5;

      // Text
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(30, 30, 46);
      textLines.forEach((line) => {
        if (y > doc.internal.pageSize.getHeight() - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(line, margin, y);
        y += 4.5;
      });

      y += 6;
    });

    doc.save("meeting-captions.pdf");
  }

  // ---- Init ----
  function init() {
    const restored = loadPersistence();
    if (restored) {
      hasData = true;
      showResults();
    } else {
      showUpload();
    }
  }

  init();
})();
